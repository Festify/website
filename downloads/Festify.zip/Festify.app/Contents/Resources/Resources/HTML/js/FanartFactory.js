angular.module("fanart", []).factory("Fanart", function($http){
    var apiKey = "ea88144526314e273f689be69389dd6c";

    var FanartAPI = {};

    FanartAPI.gatherFanart = function(artist, callback){
        FanartAPI.getArtistID(artist, function(err1, res1){
            if(!err1){
                FanartAPI.gatherFanartByID(res1, function(err2, res2){
                    if(!err2){
                        callback(false, res2);
                    }else{
                        callback(true, null);
                    }
                });
            }else{
                callback(true, null);
            }
        });
    };

    FanartAPI.gatherFanartByID = function(artistID, callback){
        FanartAPI.getFanart(artistID, function(err, content){
            if(!err && content != null){
                var hdmusiclogo = null, artistbackground = null;

                if(content['hdmusiclogo'] != undefined && content['hdmusiclogo'].length > 0){
                    hdmusiclogo = content['hdmusiclogo'][0].url;
                }

                if(content['artistbackground'] != undefined && content['artistbackground'].length > 0){
                    artistbackground = content['artistbackground'][Math.floor(Math.random() * content['artistbackground'].length)].url;
                }

                callback(false, {logo: hdmusiclogo, background: artistbackground});
            }else{
                callback(true, null);
            }
        });
    };

    FanartAPI.getArtistID = function(artist, callback){
        $http.get('http://search.musicbrainz.org/ws/2/artist/?query=' + encodeURI(artist) + '&fmt=json')
            .success(function(body) {
                if (body['artist-list']['count'] > 0) {
                    var artistID = body['artist-list']['artist'][0]['id'];
                    callback(false, artistID);
                } else {
                    callback(true, null);
                }
            })
            .error(function(){
                callback(true, null);
            });
    };

    FanartAPI.getFanart = function(artistID, callback){
        $http.get('http://api.fanart.tv/webservice/artist/' + apiKey + '/' + artistID + '/JSON/all/1/1/')
            .success(function(body){
                if(body != null){
                    var mainIndex = "";

                    for(index in body){
                        mainIndex = index;
                        break;
                    }

                    callback(false, body[mainIndex]);
                }else{
                    callback(true, null);
                }
            })
            .error(function(){
                callback(true, null);
            });
    };

    return FanartAPI;
});