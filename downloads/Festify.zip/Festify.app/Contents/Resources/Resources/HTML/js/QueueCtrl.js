/**
 * Created by leobernard on 25/10/14.
 */

angular.module("QueueCtrl", ['fanart', 'monospaced.qrcode', 'SettingsCtrl']).controller("QueueController", function($rootScope, $scope, $http, $location, $routeParams, $interval, $timeout, $translate, Fanart, serverURL, serverProtocol) {
    $scope.queue = [];
    $scope.currentSeek = 0;
    $scope.isPlaying = false;
    $scope.isNextTrack = false;
    $scope.currentBackground = "img/bg.jpg";
    $scope.currentBackgroundBlurred = "";
    $scope.nextBackground = "";
    $scope.nextBackgroundBlurred = "";
    $scope.isAdmin = false;
    $scope.hasLibspotify = window.hasLibspotify();

    $rootScope.settingsOpen = false;

    $scope.inputs = {
        volume: 100
    };

    console.log("Init QueueCtrl");

    $interval(function(){
        $scope.isPlaying = spotify.isPlaying();
        $scope.currentSeek = spotify.getSeek();
    }, 500);

    spEvents.skipTrack = function() {
        $scope.nextTrack();
    };

    $scope.$watch("queue", function(newVal, oldVal) {
        if(oldVal.length == 0) {
            if(newVal.length > 0) {
                $scope.startQueue();
            }
        }else{
            if(newVal.length > 0) {
                if(oldVal[0].id != newVal[0].id) {
                    spotify.log("Starting queue.");
                    $scope.startQueue();
                }
            }
        }

        if(newVal.length > 1) {
            if(oldVal[1].id != newVal[1].id || oldVal.length == 0) {
                console.log("Preloading Track.");
                spotify.preloadTrack(newVal[1].id);
            }
        }

        if(newVal.length == 0){
            spotify.log("Pausing Player.");
            spotify.pausePlayer();
            $scope.currentBackground = "";
        }
    }, true);

    $scope.changeVolume = function(newVal) {
        spotify.setVolume(newVal/100);
    };

    $scope.openFestifyWebsite = function(){
        spotify.openExternal('http://getfestify.com');
    };

    $scope.openPartyInBrowser = function(){
        spotify.openExternal(serverProtocol + '://' + serverURL + '/' + $rootScope.party._id);
    };

    $scope.blurImage = function(){
        spotify.log("Image loaded.");

        if(spotify.getString("blurBackgroundImage") == "1" || !$scope.hasLibspotify) {
            stackBlurImage("backgroundLoader", "backgroundCanvas", 10, false);
            spotify.log("Image blurred.");
        }else{
            var image = document.getElementById("backgroundLoader");
            var canvas = document.getElementById("backgroundCanvas");
            canvas.width = image.naturalWidth;
            canvas.height = image.naturalHeight;

            canvas.getContext("2d").drawImage(image, 0, 0);
            spotify.log("Image transferred.");
        }

        $scope.currentBackgroundBlurred = document.getElementById("backgroundCanvas").toDataURL();
    };

    $scope.refreshQueue = function(){
        $http.get(serverProtocol + "://" + serverURL + "/api/parties/" + $routeParams.partyID + "/queue?limit=" + Math.ceil(window.innerHeight / 108))
            .success(function(data, status, headers, config) {
                $rootScope.populateTrackInfo(data.slice(0, 49), function(res){
                    $scope.queue = $rootScope.addTrackTime(res);
                });
            })
            .error(function(data, status, headers, config) {
                if(status == 404){
                    $rootScope.addMessage("This Party doesn't exist anymore.", "error");
                }else{
                    $rootScope.addMessage("Our servers don't seem to work correctly at the moment.", "error");
                }
            });
    };

    $scope.startQueue = function(){
        console.log("Track-ID:", $scope.queue[0].id);
        spotify.crossfadeToTrack($scope.queue[0].id, !$scope.isNextTrack);
        $scope.isNextTrack = false;

        console.log("Gathering Fanart...");
        Fanart.gatherFanart($scope.queue[0].artists[0].name, function(err, res){
            if(!err){
                $scope.currentBackground = res.background || $scope.queue[0].album.images[0].url;
            }else{
                $scope.currentBackground = $scope.queue[0].album.images[0].url;
            }
        });
    };

    $scope.playPause = function(){
        if($scope.isPlaying){
            spotify.pausePlayer();
        }else{
            spotify.resumePlayer();
        }

        $scope.isPlaying = !$scope.isPlaying;
    };

    key('space', function() {
        if(!$scope.settingsOpen && $scope.hasLibspotify) {
            $scope.playPause();
        }
    });

    $scope.nextTrack = function(){
        $http.get(serverProtocol + "://" + serverURL + "/api/parties/" + $routeParams.partyID + "/queue/nextTrack")
            .success(function(){
                $scope.refreshQueue();
            })
            .error(function(){
                $rootScope.addMessage("Could not skip to the next Track because of a server error.", "error");
            });

        $scope.queue.shift();
        $scope.queue = $rootScope.addTrackTime($scope.queue);
    };

    window.spEvents.nextTrack = function(){
        if($scope.queue.length >= 1 && $scope.isAdmin) {
            $scope.isNextTrack = true;
            $scope.nextTrack();
        }
    };

    $rootScope.loadParty($routeParams.partyID, function(){
        console.log("Party loaded.", $rootScope.socket);

        $scope.isAdmin = ($rootScope.adminPassword);

        $scope.refreshQueue(true);

        $rootScope.socket.on("playlistChange", function(data){
            console.log("playlistChange", data);
            console.log("queueLength is", $scope.queue.length);
            $scope.refreshQueue($scope.queue.length == 0);
        });

        if(!$scope.isAdmin) {
            $rootScope.socket.on("nextTrack", function(data){
                $scope.refreshQueue($scope.queue.length == 0);
            });
        }else{
            $rootScope.socket.on("playerPlay", function(data) {
                spotify.resumePlayer();
            });

            $rootScope.socket.on("playerPause", function(data) {
                spotify.pausePlayer();
            });

            $rootScope.socket.on("playerNext", function(data) {
                $scope.nextTrack();
            });
        }
    });
});