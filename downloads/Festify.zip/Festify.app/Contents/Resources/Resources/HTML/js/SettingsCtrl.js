/**
 * Created by leobernard on 25/10/14.
 */
angular.module("SettingsCtrl", ['spotify']).controller("SettingsController", function($rootScope, $routeParams, $scope, $http, Spotify, serverURL, serverProtocol, $translate) {
    $scope.userPlaylists = null;
    $scope.newParty = JSON.parse(JSON.stringify($rootScope.party));

    window.spEvents.gotUserPlaylists = function(playlists) {
        for(var i = 0; i < playlists.length; i++) {
            playlists[i].added = ($rootScope.party.fallbackPlaylist.url == playlists[i].url);
            playlists[i].pindex = i;
        }

        $scope.userPlaylists = playlists;
    };

    spotify.getUserPlaylists();

    $scope.savePlaylist = function() {
        var tracks = [];

        $rootScope.addMessage("Creating playlist. This could take a while.");

        $http.get(serverProtocol + "://" + serverURL + "/api/parties/" + $routeParams.partyID + "/queue")
            .success(function(queueData) {
                $http.get("https://" + serverURL + "/api/parties/" + $routeParams.partyID + "/history")
                    .success(function(historyData) {
                        tracks = tracks.concat(
                            historyData.reverse().map(function(obj){return obj.spotifyID}),
                            queueData.filter(function(obj){return obj.votes > 0}).map(function(obj){return obj.spotifyID})
                        );

                        spEvents.playlistCreated = function(name, url) {
                            console.log(name, url);

                            $translate("We saved your party as {{name}}. Click this message to open it in Spotify.", {name: name.valueOf()}).then(function(text){
                                $rootScope.addMessage(text, "", 10000, function() {
                                    spotify.openExternal(url);
                                });
                            });
                        };

                        spotify.createPlaylist($rootScope.party.name, tracks.join(";"));
                    })
                    .error(function() {
                        $rootScope.addMessage("Couldn't load track history. Please try it again later.", "error");
                    })
            })
            .error(function() {
                $rootScope.addMessage("Couldn't load the current queue. Please try it again later.", "error");
            })
    };

    $scope.addFallbackPlaylist = function(index){
        var playlist = $scope.userPlaylists[index];

        spotify.log("Adding Playlist", playlist.name);

        $http.post(serverProtocol + "://" + serverURL + "/api/parties/" + $routeParams.partyID + "/queue/fallbackTracks", {
            name: playlist.name,
            url: playlist.url,
            owner: playlist.owner,
            tracks: playlist.tracks.map(function(obj, index){
                return {spotifyID: obj.id, name: obj.name}
            })
        })
            .success(function(data, status, headers, config){
                spotify.log("Added Playlist", playlist.name, "as fallback");

                for(var i = 0; i < $scope.userPlaylists.length; i++) {
                    $scope.userPlaylists[i].added = false;
                }

                $scope.userPlaylists[index].added = true;
            })
    };

    $scope.updateSettings = function(){
        $http.put(serverProtocol + "://" + serverURL + "/api/parties/" + $routeParams.partyID, {
            name: $scope.newParty.name
        })
            .success(function(data, status, headers, config){
                spotify.log("Saved Party Settings: " + JSON.stringify(data));
                $rootScope.party = data;
                spotify.saveString("lastParty", JSON.stringify(data));
            })
    };

    $scope.showPassword = function(){
        $translate("Your Admin Password is {{password}}, remember it well.", {password: $rootScope.adminPassword}).then(function(text){
            $rootScope.addMessage(text, "", 10000, false);
        })
    };

    $scope.openParty = function(){
        spotify.openExternal("http://" + serverURL + "/" + $rootScope.party._id + "/qr");
    };
});