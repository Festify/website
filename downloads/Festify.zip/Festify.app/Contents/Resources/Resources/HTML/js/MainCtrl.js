/**
 * Created by leobernard on 25/10/14.
 */
angular.module("MainCtrl", ['spotify']).controller("MainController", function($rootScope, $scope, $http, $interval, $timeout, $translate, Spotify, serverURL, serverProtocol, socketURL, socketPort) {
    $rootScope.party = null;
    $rootScope.adminPassword = "";
    $rootScope.cachedTracks = {};
    $rootScope.socket = null;
    $rootScope.serverURL = serverURL;
    $rootScope.messages = [];
    $rootScope.messageCounter = 0;
    $rootScope.reconnecting = false;

    window.spEvents.lostToken = function(){
        $rootScope.addMessage("This Spotify Account is being used somewhere else. Festify will try to continue the playback...");
    };

    window.spEvents.streamingError = function(){
        $rootScope.addMessage("There was a streaming error.", "error");
    };

    window.spEvents.networkError = function(desc, res) {
        $translate("There was a network Error: {{error}}", {error: desc}).then(function(text){
            $rootScope.addMessage(text, "error");
        });
    };

    window.spEvents.generalError = function(desc) {
        $rootScope.addMessage(desc, "error");
    };

    $rootScope.addMessage = function(text, type, timeout, callback) {
        $translate(text).then(function(translatedText){
            var msg = {
                id: $rootScope.messageCounter++,
                text: translatedText,
                type: type || "default",
                action: callback || function(msg){$rootScope.removeMessage(msg.id)}
            };

            $rootScope.messages.unshift(msg);

            $timeout(function(){
                $rootScope.removeMessage(msg.id);
            }, timeout || 5000);
        })
    };

    $rootScope.removeMessage = function(messageId){
        for(var i = 0; i < $rootScope.messages.length; i += 1) {
            if($rootScope.messages[i].id === messageId) {
                $rootScope.messages.splice(i, 1);
                break;
            }
        }
    };

    $rootScope.loadParty = function(id, callback){
        $http.get(serverProtocol + "://" + serverURL + "/api/parties/" + id).
            success(function(data, status, headers, config) {
                $rootScope.party = data;

                $rootScope.connectSocket(data._id);

                try{
                    $rootScope.adminPassword = spotify.getString("partypass_" + data._id);
                }catch(e){
                    $rootScope.adminPassword = null;
                }

                callback(data);
            }).
            error(function(data, status, headers, config) {
                $translate("We couldn't load this party. Error code: {{errorcode}}", {errorcode: status}).then(function(text){
                    $rootScope.addMessage(text, "error");
                })
            });
    };

    $rootScope.reloadParty = function(callback){
        $http.get(serverProtocol + "://" + serverURL + "/api/parties/" + $rootScope.party._id).
            success(function(data, status, headers, config) {
                $rootScope.party = data;
                callback(data);
            }).
            error(function(data, status, headers, config) {
                $translate("We couldn't reload this party. Error code: {{errorcode}}", {errorcode: status}).then(function(text){
                    $rootScope.addMessage(text, "error");
                })
            });
    };

    $rootScope.connectSocket = function(id) {
        $rootScope.socket = io("http://" + socketURL + "/" + id, {port: socketPort});

        $rootScope.socket.on("connect", function(){
            if($rootScope.reconnecting)
                $rootScope.addMessage("Reconnected to the Real-Time Server. Have fun!", "success");
        });

        $rootScope.socket.on("connect_error", function(){
            $rootScope.addMessage("Could not connect to the Real-Time Server. Retrying...");
        });

        $rootScope.socket.on("connect_timeout", function(){
            $rootScope.addMessage("Connection to the Real-Time Server timed out. Retrying...");
        });

        $rootScope.socket.on("reconnect_attempt", function(){
            $rootScope.reconnecting = true;
        })
    };

    $rootScope.populateTrackInfo = function(tracks, callback){
        var serverData = {},
            newTrackIDs = [],
            cachedTrackIDs = [],
            populatedTracks = [];

        var uniqueIDs = [];

        var trackIDs = tracks.filter(function(track){
            if(uniqueIDs.indexOf(track.spotifyID) > -1) {
                console.log("Dupe:", track);
                return false;
            }else{
                uniqueIDs.push(track.spotifyID);
            }

            return track.spotifyID.length == 22;
        }).map(function(track){
            return track.spotifyID;
        });

        for(var i = 0; i < tracks.length; i++){
            serverData[tracks[i].spotifyID] = tracks[i];
        }

        for(i = 0; i < trackIDs.length; i++){
            if($rootScope.cachedTracks.hasOwnProperty(trackIDs[i])){
                cachedTrackIDs.push(trackIDs[i]);
            }else{
                newTrackIDs.push(trackIDs[i]);
            }
        }

        for(i = 0; i < cachedTrackIDs.length; i++){
            $rootScope.cachedTracks[cachedTrackIDs[i]].serverData = serverData[cachedTrackIDs[i]];
        }

        var sortTracks = function(){
            for(i = 0; i < trackIDs.length; i++){
                if($rootScope.cachedTracks.hasOwnProperty(trackIDs[i])) {
                    var track = $rootScope.cachedTracks[trackIDs[i]];
                    track.serverData.order = i;
                    populatedTracks.push(track);
                }else{
                    spotify.log("Couldn't load track " + trackIDs[i]);
                }
            }
        };

        if(newTrackIDs.length > 0){
            Spotify.getTracks(newTrackIDs.slice(0, 49)).then(function(data){
                for(var i = 0; i < data.tracks.length; i++){
                    var track = data.tracks[i];
                    track.serverData = serverData[track.id];
                    $rootScope.cachedTracks[track.id] = track;
                }

                sortTracks();
                callback(populatedTracks);
            });
        }else{
            sortTracks();
            callback(populatedTracks);
        }
    };

    $rootScope.addTrackTime = function(tracks){
        var time = 0;

        for(var i = 0; i < tracks.length; i++) {
            tracks[i].playsIn = Math.round(time/1000);
            time += tracks[i].duration_ms;
        }

        return tracks;
    };
});