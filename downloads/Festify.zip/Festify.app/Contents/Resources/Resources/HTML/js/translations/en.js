angular.module("festifyHost")
    .config(function ($translateProvider) {
        $translateProvider.translations('en', {
            /* ====== Start Screen ====== */
            'Welcome to Festify!':
                'Welcome to Festify!',
            'Festify allows you to let your guests choose what music should be played on your party using their smartphones':
                'Festify allows you to let your guests choose what music should be played on your party using their smartphones',
            'Start a new party':
                'Start a new party',
            'Reopen last party':
                'Reopen last party',
            'Join a party':
                'Join a party',
            'My Party':
                'My Party',
            'Join this Party as the Admin!':
                'Join this Party as the Admin!',
            'Join this Party as a Guest!':
                'Join this Party as a Guest!',
            'or':
                'or',

            /* ====== Settings Screen ====== */
            'Party Settings':
                'Party Settings',
            'Basic Settings':
                'Basic Settings',
            'Party Name':
                'Party Name',
            'Give your party a witty name':
                'Give your party a witty name',
            'More settings coming soon...':
                'More settings coming soon...',
            'Save Settings':
                'Save Settings',
            'Show Password':
                'Show Password',
            'Share Party':
                'Share Party',
            'Will be played when the queue is empty.':
                'Will be played when the queue is empty.',
            'Search your Playlists':
                'Search your Playlists',
            'No tracks':
                'No tracks',
            'One track':
                'One track',
            '{} tracks':
                '{} tracks',

            /* ====== Queue Screen ====== */
            'Join this party!':
                'Join this party!',
            'The queue is currently empty.':
                'The queue is currently empty.',
            'Go to {serverURL} and enter the code above to add and vote for songs in this queue':
                'Go to {{serverURL}} and enter the code above to add and vote for songs in this queue',
            'Go to {serverURL} and enter the code on the left to add and vote for songs in this queue.':
                'Go to {{serverURL}} and enter the code on the left to add and vote for songs in this queue.',
            'Fallback Track':
                'Fallback Track',
            'One vote':
                'One vote',
            '{} votes':
                '{} votes',
            'Guest Mode':
                'Guest Mode',

            /* ====== Messages ====== */
            "This Party doesn't exist anymore.":
                "This Party doesn't exist anymore.",
            "Our servers don't seem to work correctly at the moment.":
                "Our servers don't seem to work correctly at the moment.",
            "Could not skip to the next Track because of a server error.":
                "Could not skip to the next Track because of a server error.",
            "This Spotify Account is being used somewhere else. Festify will try to continue the playback...":
                "This Spotify Account is being used somewhere else. Festify will try to continue the playback...",
            "There was a streaming error.":
                "There was a streaming error.",
            "There was a network Error: {{error}}":
                "There was a network Error: {{error}}",
            "We couldn't load this party. Error code: {{errorcode}}":
                "We couldn't load this party. Error code: {{errorcode}}",
            "We couldn't reload this party. Error code: {{errorcode}}":
                "We couldn't reload this party. Error code: {{errorcode}}",
            "Reconnected to the Real-Time Server. Have fun!":
                "Reconnected to the Real-Time Server. Have fun!",
            "Could not connect to the Real-Time Server. Retrying...":
                "Could not connect to the Real-Time Server. Retrying...",
            "Connection to the Real-Time Server timed out. Retrying...":
                "Connection to the Real-Time Server timed out. Retrying...",
            "Your Admin Password is {{password}}, remember it well.":
                "Your Admin Password is {{password}}, remember it well.",
            "An error occurred while creating the party. Please try it again later.":
                "An error occurred while creating the party. Please try it again later.",
            "Loading last Party. This could take a moment.":
                "Loading last Party. This could take a moment.",
            "The last party could not be found.":
                "The last party could not be found.",
            "There doesn't seem to be any last party. Please start a new party first.":
                "There doesn't seem to be any last party. Please start a new party first."
        });
    });
