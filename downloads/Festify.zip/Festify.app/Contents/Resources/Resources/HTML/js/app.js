angular
    .module("festifyHost", ['pascalprecht.translate', 'ngRoute', 'ngDialog', 'MainCtrl', 'StartCtrl', 'QueueCtrl'])

    .constant("serverURL", "festify.us")

    .constant("serverProtocol", "https")

    .constant("socketURL", "io.festify.us")

    .constant("socketPort", 1339)

    .config(['$translateProvider', function ($translateProvider) {
        $translateProvider.preferredLanguage(spotify.getPreferredLanguage());
        $translateProvider.fallbackLanguage('en');
    }])

    .config(['$routeProvider',
        function($routeProvider) {
            $routeProvider
                .when('/', {
                    templateUrl: 'templates/start-screen.html',
                    controller: 'StartController'
                })
                .when('/join', {
                    templateUrl: 'templates/join-screen.html',
                    controller: 'StartController'
                })
                .when('/:partyID', {
                    templateUrl: 'templates/party-queue.html',
                    controller: 'QueueController'
                })
                .when('/:partyID/settings', {
                    templateUrl: 'templates/party-settings.html',
                    controller: 'QueueAddController'
                })
                .otherwise({
                    redirectTo: '/'
                })
        }
    ])

    .directive('backImg', function(){
        return function(scope, element, attrs){
            attrs.$observe('backImg', function(value) {
                element.css({
                    'background-image': 'url(' + value +')'
                });
            });
        }
    })

    .filter('niceTime', function(){
        return function(totalSec){
            totalSec = Math.abs(Math.floor(totalSec));

            var minutes = Math.floor(totalSec / 60);
            var seconds = Math.ceil(totalSec % 60);

            return (minutes < 10 ? "0" + minutes : minutes) + ":" + (seconds  < 10 ? "0" + seconds : seconds);
        }
    })

    .directive('imgLoad', function() { // 'imgLoad'
        return {
            restrict: 'A',
            scope: {
                loadHandler: '&imgLoad' // 'imgLoad'
            },
            link: function (scope, element, attr) {
                element.on('load', scope.loadHandler);
            }
        };
    })

    .factory('adminPasswordInterceptor', ['$q', '$rootScope', function($q, $rootScope) {
        return {
            request: function(config) {
                if(config.url.indexOf("fstfy.de") != -1 || config.url.indexOf("festify.us") != -1) {
                    if($rootScope && $rootScope.adminPassword){
                        config.headers['Admin-Password'] = $rootScope.adminPassword;
                    }
                }
                return config || $q.when(config);
            }
        };
    }])

    .factory('loadingStatusInterceptor', function($q, $rootScope) {
        var activeRequests = 0;

        $rootScope.xhrLoading = false;

        var started = function() {
            if(activeRequests==0) {
                $rootScope.xhrLoading = true;
            }
            activeRequests++;
        };
        var ended = function() {
            activeRequests--;
            if(activeRequests==0) {
                $rootScope.xhrLoading = false;
            }
        };
        var error = function(rejection) {
            activeRequests--;
            if(activeRequests==0) {
                $rootScope.xhrLoading = false;
            }
        };
        return {
            request: function(config) {
                started();
                return config || $q.when(config);
            },
            response: function(response) {
                ended();
                return response || $q.when(response);
            },
            responseError: function(rejection) {
                error(rejection);
                return $q.reject(rejection);
            }
        };
    })

    .config(function($httpProvider) {
        $httpProvider.interceptors.push('adminPasswordInterceptor');
        $httpProvider.interceptors.push('loadingStatusInterceptor');
    });