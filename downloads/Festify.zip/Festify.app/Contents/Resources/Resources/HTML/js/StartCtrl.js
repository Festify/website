/**
 * Created by leobernard on 25/10/14.
 */
angular.module("StartCtrl", []).controller("StartController", function($rootScope, $scope, $http, $location, $translate, serverURL, serverProtocol) {
    if(!hasLibspotify()) document.location.href = "https://festify.us";

    try {
        $scope.lastParty = JSON.parse(spotify.getString("lastParty"));
    }catch(e){
        $scope.lastParty = null;
    }

    $scope.knowsPassword = false;

    $scope.inputs = {
        joinID: ""
    };

    $scope.createParty = function(){
        $translate("My Party").then(function(partyName){
            $http.post(serverProtocol + "://" + serverURL + "/api/parties", {
                name: partyName,
                spotifyUser: spotify.getUserName(),
                countryCode: spotify.getLocale()
            }).success(function(data, status, headers, config){
                $rootScope.party = data;
                spotify.saveString("lastParty", JSON.stringify(data));
                spotify.saveString("partypass_" + data._id, data.adminPassword);
                spotify.saveString("partypass_" + data.publicPartyID, data.adminPassword);
                $location.path("/" + data._id);
            }).error(function(data, status, headers, config){
                $rootScope.addMessage("An error occurred while creating the party. Please try it again later.", "error");
            });
        });
    };

    $scope.joinParty = function(){
        if($scope.lastParty != null){
            $rootScope.addMessage("Loading last Party. This could take a moment.", "", 2000);

            $http.get(serverProtocol + "://" + serverURL + "/api/parties/" + $scope.lastParty._id)
                .success(function(party){
                    $rootScope.party = party;
                    spotify.saveString("lastParty", JSON.stringify(party));

                    $location.path("/" + party._id);
                })
                .error(function(){
                    $rootScope.addMessage("The last party could not be found.", "error");
                })
        }else{
            $rootScope.addMessage("There doesn't seem to be any last party. Please start a new party first.", "error");
        }
    };

    $scope.joinExternal = function() {
        $location.path('/join');
    };

    $scope.$watch("inputs.joinID", function(newVal) {
        $scope.knowsPassword = !!spotify.getString("partypass_" + newVal);
    });

    $scope.joinExternalByPublicID = function(publicID) {
        $http.get(serverProtocol + "://" + serverURL + "/api/parties/byPublicID/" + publicID)
            .success(function(party){
                if(party.spotifyUser != spotify.getUserName() || $scope.knowsPassword) {
                    $rootScope.party = party;
                    $rootScope.adminPassword = null;
                    spotify.saveString("lastParty", JSON.stringify(party));
                    $location.path("/" + party._id);
                }else{
                    $rootScope.addMessage("You can't join this party when you're logged in as the same user who created it. Please log in with another account.", "error");
                }
            })
            .error(function(){
                $rootScope.addMessage("The Party could not be found.", "error");
            })
    };
});