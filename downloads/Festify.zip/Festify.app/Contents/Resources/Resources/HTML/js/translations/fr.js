angular.module("festifyHost")
    .config(function ($translateProvider) {
        $translateProvider.translations('fr', {
            /* ====== Start Screen ====== */
            'Welcome to Festify!':
                'Bienvenue à Festify!',
            'Festify allows you to let your guests choose what music should be played on your party using their smartphones':
                'Festify vous permet de laisser vos invités choisissent ce que la musique doit être joué sur votre partie en utilisant leurs smartphones',
            'Start a new party':
                'Lancer un nouveau parti',
            'Reopen last party':
                'Ouvrez dernier parti',
            'Join a party':
                'Adhérer à un parti',
            'My Party':
                'Ma fête',
            'or':
                'ou',

            /* ====== Settings Screen ====== */
            'Party Settings':
                'Réglages du Parti',
            'Basic Settings':
                'Paramètres de base',
            'Party Name':
                'Nom Parti',
            'Give your party a witty name':
                'Donnez votre parti un bon nom',
            'More settings coming soon...':
                'Plus de paramètres à venir ...',
            'Save Settings':
                'Enregistrer les paramètres',
            'Show Password':
                'Afficher Mot de passe',
            'Share Party':
                'Partager la fête',
            'Will be played when the queue is empty.':
                'Will be played when the queue is empty.',
            'Search your Playlists':
                'Rechercher vos Playlists',
            'No tracks':
                'Pas de pistes',
            'One track':
                'Une piste',
            '{} tracks':
                '{} pistes',

            /* ====== Queue Screen ====== */
            'Join this party!':
                'Joignez-vous à cette fête!',
            'The queue is currently empty.':
                'La playlist est actuellement vide.',
            'Go to {serverURL} and enter the code above to add and vote for songs in this queue':
                'Allez à {{serverURL}} et entrez le code pour ajouter et voter pour de chansons',
            'Go to {serverURL} and enter the code on the left to add and vote for songs in this queue.':
                "Aller à {{serverURL}} et entrez le code sur la gauche pour ajouter et voter pour les chansons dans cette file d'attente.",
            'Fallback Track':
                'Fallback Track',
            'One vote':
                'Un vote',
            '{} votes':
                '{} votes',

            /* ====== Messages ====== */
            "This Party doesn't exist anymore.":
                "Ce parti n'existe plus.",
            "Our servers don't seem to work correctly at the moment.":
                "Nos serveurs ne semblent pas fonctionner correctement au moment.",
            "Could not skip to the next Track because of a server error.":
                "Impossible de passer à la piste suivante à cause d'une erreur de serveur.",
            "This Spotify Account is being used somewhere else. Festify will try to continue the playback...":
                "Ce compte Spotify est utilisé ailleurs. Festify va essayer de continuer la lecture...",
            "There was a streaming error.":
                "Il y avait une erreur de streaming.",
            "There was a network Error: {{error}}":
                "Il y avait une erreur de réseau: {{error}}",
            "We couldn't load this party. Error code: {{errorcode}}":
                "Nous ne pouvions pas charger ce parti. Code d'erreur: {{errorcode}}",
            "We couldn't reload this party. Error code: {{errorcode}}":
                "We couldn't reload this party. Error code: {{errorcode}}",
            "Reconnected to the Real-Time Server. Have fun!":
                "Reconnecté au serveur real-time.",
            "Could not connect to the Real-Time Server. Retrying...":
                "Impossible de se connecter au serveur real-time. Nouvelle tentative...",
            "Connection to the Real-Time Server timed out. Retrying...":
                "Connexion au serveur real-time expiré. Nouvelle tentative...",
            "Your Admin Password is {{password}}, remember it well.":
                "Votre mot de passe administrateur est {{password}}, rappelez-vous bien.",
            "An error occurred while creating the party. Please try it again later.":
                "Une erreur est survenue lors de la création du parti. S'il vous plaît essayer de nouveau plus tard.",
            "Loading last Party. This could take a moment.":
                "Chargement dernière Partie. Cela pourrait prendre un moment.",
            "The last party could not be found.":
                "La dernière partie est introuvable.",
            "There doesn't seem to be any last party. Please start a new party first.":
                "Il ne semble pas y avoir de dernier parti. S'il vous plaît commencer un nouveau parti premier."
        });
    });
