angular.module("festifyHost")
    .config(function ($translateProvider) {
        $translateProvider.translations('de', {
            /* ====== Start Screen ====== */
            'Welcome to Festify!':
                'Willkommen bei Festify!',
            'Festify allows you to let your guests choose what music should be played on your party using their smartphones':
                'Festify erlaubt es dir, deine Gäste per Smartphone wählen zu lassen, welche Musik auf deiner Party laufen soll',
            'Start a new party':
                'Neue Party starten',
            'Reopen last party':
                'Letzte Party öffnen',
            'Join a party':
                'Party beitreten',
            'My Party':
                'Meine Party',
            'Join this Party as the Admin!':
                'Party als Administrator öffnen!',
            'Join this Party as a Guest!':
                'Dieser Party als Gast beitreten!',
            'or':
                'oder',

            /* ====== Settings Screen ====== */
            'Party Settings':
                'Party-Einstellungen',
            'Basic Settings':
                'Grundeinstellungen',
            'Party Name':
                'Party-Name',
            'Give your party a witty name':
                'Gib deiner Party einen originellen Namen',
            'More settings coming soon...':
                'Mehr Einstellungen kommen bald...',
            'Save Settings':
                'Einstellungen speichern',
            'Show Password':
                'Passwort zeigen',
            'Share Party':
                'Party teilen',
            'Will be played when the queue is empty.':
                'Wird gespielt, wenn die Warteschlange leer ist.',
            'Search your Playlists':
                'Durchsuche deine Playlists',
            'No tracks':
                'Keine Songs',
            'One track':
                'Ein Song',
            '{} tracks':
                '{} Songs',

            /* ====== Queue Screen ====== */
            'Join this party!':
                'Tritt der Party bei!',
            'The queue is currently empty.':
                'Die Playlist ist momentan leer.',
            'Go to {serverURL} and enter the code above to add and vote for songs in this queue':
                'Gehe auf {{serverURL}} und gib den Code ein, um Songs vorzuschlagen und mitzuwählen',
            'Go to {serverURL} and enter the code on the left to add and vote for songs in this queue.':
                'Gehe auf {{serverURL}} und gib den Party-Code links unten ein, um Songs vorzuschlagen und mitzuwählen.',
            'Fallback Track':
                'Reserve-Track',
            'One vote':
                'Eine Stimme',
            '{} votes':
                '{} Stimmen',
            'Guest Mode':
                'Gastmodus',

            /* ====== Messages ====== */
            "This Party doesn't exist anymore.":
                "Diese Party existiert nicht mehr.",
            "Our servers don't seem to work correctly at the moment.":
                "Unsere Server scheinen im Moment nicht zu funktionieren.",
            "Could not skip to the next Track because of a server error.":
                "Wegen eines Serverfehlers kann nicht zum nächsten Track gesprungen werden.",
            "This Spotify Account is being used somewhere else. Festify will try to continue the playback...":
                "Dieser Spotify Account wird anderswo verwender. Festify versucht, die Wiedergane fortzusetzen...",
            "There was a streaming error.":
                "Ein Streaming-Fehler ist aufgetreten.",
            "There was a network Error: {{error}}":
                "Ein Netzwerkfahler ist aufgetreten: {{error}}",
            "We couldn't load this party. Error code: {{errorcode}}":
                "Wir konnten diese Party nicht laden. Fehler-Code: {{errorcode}}",
            "We couldn't reload this party. Error code: {{errorcode}}":
                "Wir konnten diese Party nicht aktualisieren. Fehler-Code: {{errorcode}}",
            "Reconnected to the Real-Time Server. Have fun!":
                "Verbindung zum Echtzeitserver wiederhergestellt. Viel Spaß!",
            "Could not connect to the Real-Time Server. Retrying...":
                "Verbindung zum Echtzeitserver konnte nicht hergestellt werden. Festify versucht es erneut...",
            "Connection to the Real-Time Server timed out. Retrying...":
                "Verbindung zum Echtzeitserver ist abgebrochen. Festify versucht es erneut...",
            "Your Admin Password is {{password}}, remember it well.":
                "Dein Admin-Passwort ist {{password}}, merke es dir gut.",
            "An error occurred while creating the party. Please try it again later.":
                "Bei der Erstellung der Party ist ein Fehler aufgetreten. Bitte versuche es später erneut.",
            "Loading last Party. This could take a moment.":
                "Die letzte Party wird geladen. Das kann ein Weilchen dauern.",
            "The last party could not be found.":
                "Die letzte Party konnte nicht gefunden werden.",
            "There doesn't seem to be any last party. Please start a new party first.":
                "Es scheint keine letzte Party zu geben. Bitte starte zuerst eine neue Party."
        });
    });
