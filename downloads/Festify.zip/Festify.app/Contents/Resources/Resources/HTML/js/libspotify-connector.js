var dummyTime = 0;

function spotifyTrackEnded(){
    interop.log("Jup. Track ended.");
    if(window.spEvents.nextTrack) window.spEvents.nextTrack();
}

function spotifyGotUserPlaylists(playlists) {
    interop.log("Jup. Playlists received.");
    if(window.spEvents.gotUserPlaylists) window.spEvents.gotUserPlaylists(JSON.parse(playlists));
}

function spotifyLostToken(){
    interop.log("Jup. Lost token.");
    if(window.spEvents.lostToken) window.spEvents.lostToken();
}

function spotifyStreamingError(){
    interop.log("Jup. Streaming Error.");
    if(window.spEvents.streamingError) window.spEvents.streamingError();
}

function spotifyGeneralError(desc){
    interop.log("Jup. General Error.");
    if(window.spEvents.streamingError) window.spEvents.generalError(desc);
}

function spotifyTrackStarted() {
    interop.log("Jup. Track started.");
}

function spotifyNetworkError(desc, cause) {
    interop.log("Jup. Network error.");
    if(window.spEvents.networkError) window.spEvents.networkError(desc, cause);
}

function spotifySkipTrack() {
    interop.log("Jup. Network error.");
    if(window.spEvents.skipTrack) window.spEvents.skipTrack();
}

function spotifyPlaylistCreated(name, url) {
    interop.log("Jup. Playlist created: " + name + "; " + url);
    if(window.spEvents.playlistCreated) window.spEvents.playlistCreated(name, url);
}

window.spEvents = {
    nextTrack: null,
    gotUserPlaylists: null,
    lostToken: null,
    streamingError: null,
    networkError:null,
    generalError: null,
    skipTrack: null,
    playlistCreated: null
};

if(window.interop){
    var spotify = window.interop;
}else{
    var dummyInterval;

    var spotify = {
        isPlaying: function() {
            return true;
        },
        getSeek: function(){
            return dummyTime;
        },
        getUserPlaylists: function(){
            return [];
        },
        getLocale: function(){
            return "en";
        },
        getUserName: function(){
            return "testuser";
        },
        preloadTrack: function(id){
            console.log("Would now preload track", id);
            return true;
        },
        createPlaylist: function(name, tracks){
            return true;
        },
        log: function(string) {
            console.log("[WebApp] " + string);
        },
        playTrack: function(id){
            clearInterval(dummyInterval);
            dummyTime = 0;

            dummyInterval = setInterval(function() {
                dummyTime += 0.2;
            }, 200);

            return true;
        },
        setVolume: function(volume){
            return true;
        },
        crossfadeToTrack: function(id, time){
            clearInterval(dummyInterval);
            dummyTime = 0;

            dummyInterval = setInterval(function() {
                dummyTime += 0.2;
            }, 200);

            return true;
        },
        saveString: function(key, value){

        },
        getString: function(key){
            return undefined;
        },
        pausePlayer: function(){
            clearInterval(dummyInterval);
            return true;
        },
        resumePlayer: function(){
            dummyInterval = setInterval(function() {
                dummyTime += 0.2;
            }, 200);
            return true;
        },
        openExternal: function(url){
            window.open(url);
        },
        getPreferredLanguage: function(){
            return "en";
        }
    }
}

window.hasLibspotify = function() {
    return !!window.interop;
};
